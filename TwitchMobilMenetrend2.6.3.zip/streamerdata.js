/**MobilBarát Menetrend Testreszabása. */
/*Streamer adatok megadása*/

//A twitch neved amivel a csatorna elérhető --> http://twitch.tv/twitchneved.
var streamer = "twitchneved";
//Kép megjelenítése amikor üres a menetrend.
var noEventsPic = "https://peldakep.hu/kep.png";
//Kép megjelenítése amikor offline a menetrend(nembiztos, hogy megjelenik majd offline állapotban)
var offlinePic = "https://peldakep.hu/kep.png";
//Offline állapotban megjelenő szöveg
var offlineText = "Nincs internet!"; 
//Üres menetrendkor megjelenő szöveg
var noEventsText = "Menetrend Jelenleg üres!";

